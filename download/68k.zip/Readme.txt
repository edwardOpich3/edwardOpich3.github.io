This disassembler is intended only for use with valid 68000 binary files, usage with anything else will produce nonsense code.

The disassembler is used from the command line, with the following format:

	68K_Disassembler.exe [Flags] "S.bin" "D.asm" [Start] [End]

"S.bin" is the source file, the 68000 binary file you would like to disassemble.

"D.asm" is the destination file, where the disassembly will be output to. Keep in mind that if the file already exists, it will be completely overwritten, with no warning!

[Start] and [End] are decimal numbers for which offsets to start and stop parsing at. [End] is exclusive, meaning that the code at that offset won't be parsed.

Do not include any brackets or quotes for the files or offsets, unless they are in the filename.

There are currently no flags, but I intend on building on this program to add more functionality.