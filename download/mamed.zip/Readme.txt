The editor is accessed through the command line. The format is:

	"Mazes and Monsters Level Editor.exe" level.lvl

If you start the level editor without a level filename, it will generate one named "newlevel.lvl". Beware, if you had a newlevel.lvl already and didn't rename it, it will be overwritten immediately!

Press Enter to change cursor modes.

White Cursor Mode: The cursor can move around the screen using the arrow keys.

Red Cursor Mode: The cursor is stuck in place, but can change the current tile by using the left and right arrow keys.