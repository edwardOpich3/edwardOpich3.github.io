How to operate:

Click one of the buttons on the right to select an object to place, then click the "Add Element" Button to place it. The little red "L" on the preview screen is the cursor, the object will be placed there. One can adjust the cursor with the text controls, Vector2 position. If you don't like the positioning of your object, you can click and drag it to a new location with the mouse.

If you regret placing the object, pressing delete while it is the most recently clicked object will delete it.